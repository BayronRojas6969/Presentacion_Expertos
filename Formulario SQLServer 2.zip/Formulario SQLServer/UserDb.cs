﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.VisualBasic.ApplicationServices;

namespace Formulario
{
    public class UserDb
    {

        private string connectionString
            = "Data Source=LAPTOP-1KVC8371\\SQLEXPRESS;Initial Catalog=Formulario;" +
            "User=bayron;Password=123456";


    public bool Ok()
    {
            try
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
            }
            catch
            {
                return false;
            }
            return true;
        }

        public List<Users> Get()
        { 
            List<Users> users = new List<Users>();

            string query = "select * from DbUsers";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand  command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader  reader = command.ExecuteReader();
                    while (reader.Read()) 
                    {
                        Users oUser = new Users();
                        oUser.Id = reader.GetInt32(0);
                        oUser.Nombre = reader.GetString(1);
                        oUser.Apellido = reader.GetString(2);
                        oUser.Rut = reader.GetString(3);
                        oUser.Edad = reader.GetInt32(4);
                        oUser.Teléfono = reader.GetInt32(5);
                        oUser.Correo = reader.GetString(6);
                        users.Add(oUser);
                    }
                    reader.Close();

                    connection.Close();
                }
                catch(Exception ex) 
                {
                    throw new Exception("Hay un error en la Base de datos"+ex.Message);
                }

            }

                return users;
        }


        public void Add(string Nombre, string Apellido, string Rut, int Edad, int Teléfono, string Correo) 
        {
            string query = "insert into DbUsers(Nombre, Apellido, Rut, Edad, Teléfono, Correo) values " +
                "(@Nombre, @Apellido, @Rut, @Edad, @Teléfono, @Correo)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Nombre", Nombre);
                command.Parameters.AddWithValue("@Apellido", Apellido);
                command.Parameters.AddWithValue("@Rut", Rut);
                command.Parameters.AddWithValue("@Edad", Edad);
                command.Parameters.AddWithValue("@Teléfono", Teléfono);
                command.Parameters.AddWithValue("@Correo", Correo);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();

                    connection.Close();
                }
                catch (Exception ex)
                {
                    throw new Exception("Hay un error en la Base de datos" + ex.Message);
                }

            }
        }
    }

    public class Users { 
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Rut { get; set; }
        public int Edad { get; set; }
        public int Teléfono { get; set; }
        public string Correo { get; set; }

    }
}
